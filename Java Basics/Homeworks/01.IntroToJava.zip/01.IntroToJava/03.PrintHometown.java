// Create a simple Java program PrintHometown.java (console application) 
// to print the name of your hometown, compile and run it.

public class _03_PrintHometown {

	public static void main(String[] args) {
		System.out.println("My hometwon is Pernik.");

	}

}
