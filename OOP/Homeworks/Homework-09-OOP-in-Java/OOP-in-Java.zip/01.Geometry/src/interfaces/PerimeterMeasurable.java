package interfaces;

public interface PerimeterMeasurable {
    public double getPerimeter();
}
