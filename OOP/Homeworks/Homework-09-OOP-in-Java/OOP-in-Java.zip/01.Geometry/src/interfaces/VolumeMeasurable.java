package interfaces;


public interface VolumeMeasurable {
    public double getVolume();
}
