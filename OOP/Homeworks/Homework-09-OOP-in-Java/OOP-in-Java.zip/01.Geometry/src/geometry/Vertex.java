package geometry;

public abstract class Vertex {
}
