package interfaces;

public interface Buyable {
    public double getPrice();
}
