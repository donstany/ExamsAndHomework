package models.products;

public enum AgeRestriction {
    NONE,
    TEENAGER,
    ADULT
}
