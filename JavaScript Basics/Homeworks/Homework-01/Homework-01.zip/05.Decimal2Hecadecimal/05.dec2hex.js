var num = prompt("Enter a positive integer");
var result = parseInt(num).toString(16).toUpperCase();
alert(result);